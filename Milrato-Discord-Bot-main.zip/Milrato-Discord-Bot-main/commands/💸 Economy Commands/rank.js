const eco = require("discord-economy");
module.exports = {
    name: "rank",
    category: "💸 Economy Commands",
  description: "Shows your rank level",
  usage: "rank",
  run: async (client, message, args) => {
    //CMD
  }
  };